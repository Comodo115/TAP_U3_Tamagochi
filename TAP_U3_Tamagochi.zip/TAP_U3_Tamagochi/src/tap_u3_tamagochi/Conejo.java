package tap_u3_tamagochi;

public class Conejo {
    
    public boolean jugar = false;
    public boolean comer = false;
    public boolean dormir = false;
    public boolean parado = true;
    
    public void jugar(){
        jugar = true;
        comer = false;
        dormir = false;
        parado = false;
    }
    
    public void comer(){
        jugar = false;
        comer = true;
        dormir = false;
        parado = false;
    }
    
    public void dormir(){
        jugar = false;
        comer = false;
        dormir = true;
        parado = false;
    }
    
    public boolean parar(){
        jugar = false;
        comer = false;
        dormir = false;
        parado = true;
        return parado;
    }
}

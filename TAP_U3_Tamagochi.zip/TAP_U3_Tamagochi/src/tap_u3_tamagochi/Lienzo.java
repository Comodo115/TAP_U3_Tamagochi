package tap_u3_tamagochi;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class Lienzo extends Canvas {
    
    public Lienzo() {
        this.setSize(399, 520);
        this.setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        
        Graphics2D g2 = (Graphics2D) g;
        
        g2.setColor(new Color(51,255,209));
        g2.fillRect(0, 0, 399, 520);
    }
    
}

package tap_u3_tamagochi;

import java.util.logging.Level;
import java.util.logging.Logger;

public class NivelCansancio extends Thread{
    
    int count = 100;
    public boolean muerto;
    
    @Override
    public void run() {
        while(true){
            if(Ventana.conejo.jugar == true){
                count -= 15; 
            }
            
            if(Ventana.conejo.comer == true){
                count += 10;
            }
            
            if(Ventana.conejo.dormir == true){
                count += 10;
            }
            
            if(Ventana.conejo.jugar == false && Ventana.conejo.comer == false && Ventana.conejo.dormir == false && Ventana.conejo.dormir == false){
                count -= 5;
            }
            
            Ventana.jLabel2.setText(count + "");
            try {
                sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(NivelCansancio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
